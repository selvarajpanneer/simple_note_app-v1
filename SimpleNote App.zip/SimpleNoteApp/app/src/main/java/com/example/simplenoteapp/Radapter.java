package com.example.simplenoteapp;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;


public class Radapter extends RecyclerView.Adapter<Radapter.ViewHolder> {
    private static final String TAG = "ADAPTER";
    private static final int MODE_PRIVATE = 0;
    String whole = "";

    private ArrayList<Notes> mNoteList;
    private Context rContext;
    String filename;

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView textView1, textView2, textView3;
        private View itemLayout;


        public ViewHolder(View v) {
            super(v);
            textView1 = v.findViewById(R.id.title_view);
            textView2 = v.findViewById(R.id.content_view);
            textView3 = v.findViewById(R.id.time_view);
            itemLayout = v.findViewById(R.id.single_item);
        }
    }

    public Radapter(Context context, ArrayList<Notes> list) {
        rContext = context;
        mNoteList = list;
    }

    @NonNull
    @Override
    public Radapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v1 = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_single_item_layout, parent, false);
        ViewHolder vh = new ViewHolder(v1);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull Radapter.ViewHolder holder, int position) {
        Notes nl = mNoteList.get(position);
        String file = nl.getFilename();
        try {
            FileInputStream fis = rContext.openFileInput(file);
            BufferedReader reader = new BufferedReader(new InputStreamReader(fis));
            String line;

            while ((line = reader.readLine()) != null) {
                if (whole == "") {
                    whole = whole + line;
                } else {
                    whole = whole + "\n" + line;
                }
            }
            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        String title = nl.getTitle();
        Long time = nl.getTime();
        Log.d(TAG, "onBindViewHolder: " + file + " " + title + " " + time);
        String t = checkTimePeriod(time);
        if (nl != null) {

            holder.textView1.setText(title);
            holder.textView2.setText(checkLength(whole));
            holder.textView3.setText(t);
            holder.itemLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent edit_intent = new Intent(rContext, InputSection.class);
                    edit_intent.putExtra("edit_file", file);
                    edit_intent.putExtra("edit_title", title);
                    rContext.startActivity(edit_intent);
                }
            });
        } else {
            Log.d(TAG, "onBindViewHolder: item is null");
        }

    }

    public String checkLength(String whole) {
        if (whole.length() > 20) {
            whole = whole.substring(0, 20) + "...";
            return whole;
        } else {
            return whole;
        }
    }

    public String checkTimePeriod(long time1) {
        long milliseconds1 = time1;
        long milliseconds2 = System.currentTimeMillis();
        long diff = milliseconds2 - milliseconds1;
        long seconds = diff / 1000;
        long minutes = diff / (60 * 1000);
        long hours = diff / (60 * 60 * 1000);
        long days = diff / (24 * 60 * 60 * 1000);
        if (seconds < 60) {
            String sec = seconds + " sec";
            return sec;
        } else if (minutes < 60) {
            String min = minutes + " min";
            return min;
        } else if (hours < 24) {
            String hr = hours + " hr";
            return hr;
        } else {
            String day = days + " D";
            return day;
        }
    }

    @Override
    public int getItemCount() {
        if (mNoteList != null) {
            Log.d(TAG, "getItemCount: mNoteList not null");
            return mNoteList.size();
        } else
            return 0;
    }
}