package com.example.simplenoteapp;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Random;
import java.util.TimeZone;

public class InputSection extends AppCompatActivity {

    private static final String TAG = "INPUT SECTION";
    EditText mtitle;
    EditText mcontent;
    String filename;
    String title, content;
    long time;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_storage_layout);

        mtitle = findViewById(R.id.title_of_note);
        mcontent = findViewById(R.id.content_of_note);

        //EDIT PART
        final Intent intent = getIntent();
        filename = intent.getStringExtra("edit_file");
        if (filename != null) {
            title = intent.getStringExtra("edit_title");
            mtitle.setText(title);
            try {
                FileInputStream fis = openFileInput(filename);
                BufferedReader reader = new BufferedReader(new InputStreamReader(fis));
                String line;
                String whole = "";
                while ((line = reader.readLine()) != null) {
                    if (whole == "") {
                        whole = whole + line;
                    } else {
                        whole = whole + "\n" + line;
                    }
                }
                reader.close();
                mcontent.setText(whole);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    //menu for save icon
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.action_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.item1:
                addContent();
                return true;
            case R.id.item2:
                backToMainPage();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    //SAVE AFTER EDIT OR CREATE NOTE
    private void addContent() {
        //get the input from views
        title = mtitle.getText().toString().trim();
        content = mcontent.getText().toString().trim();

        if (!title.isEmpty()) {
            if (!content.isEmpty()) {
                try {
                    //generate random number for filename
                    if (filename == null) {
                        final int random = new Random().nextInt(100) + 10;
                        filename = String.valueOf(random);
                        Log.d(TAG, "InputSection Onclick : " + filename + ".txt" + " appended");
                        filename = filename.trim() + ".txt";
                        //Store the value
                        FileOutputStream fileOutputStream = openFileOutput(filename, Context.MODE_PRIVATE);
                        fileOutputStream.write(content.getBytes());
                        fileOutputStream.close();
                        Log.d(TAG, "addContent: " + filename);
                    } else {
                        Log.d(TAG, "addContent: Use old file name" + filename);
                        FileOutputStream fileOutputStream = openFileOutput(filename, Context.MODE_PRIVATE);
                        fileOutputStream.write(content.getBytes());
                        fileOutputStream.close();
                        Log.d(TAG, "addContent: " + filename);
                    }
                    Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("GMT+5:30"));
                    time = cal.getTimeInMillis();
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else {
                Log.d(TAG, "onClick: content is empty");
            }
        } else {
            Log.d(TAG, "onClick: title is empty");
        }
    }

    public void backToMainPage() {
        Intent return_intent = new Intent();
        return_intent.putExtra("filename", filename);
        return_intent.putExtra("title", title);
        return_intent.putExtra("time", time);
        setResult(Activity.RESULT_OK, return_intent);
        finish();
    }
}



