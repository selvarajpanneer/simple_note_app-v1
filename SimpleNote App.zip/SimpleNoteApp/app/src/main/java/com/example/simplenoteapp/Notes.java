package com.example.simplenoteapp;

public class Notes {
    String filename;
    String title;
    long time;

    public Notes(String filename, String title, long time) {
        this.filename = filename;
        this.title = title;
        this.time = time;
    }

    public String getFilename() {
        return filename;
    }

    public String getTitle() {
        return title;
    }

    public long getTime() {
        return time;
    }
}
