package com.example.simplenoteapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.File;
import java.lang.reflect.Type;
import java.util.ArrayList;


public class SimpleNote extends AppCompatActivity {

    private static final String TAG = "main_activity";
    final String KEY = "Notes";
    int LAUNCH_SECOND_ACTIVITY = 2;
    FloatingActionButton mFloatingActionButton;
    ArrayList<Notes> notesList, notesArrayList;
    float dx, dy;

    RecyclerView recyclerView_View;
    RecyclerView.Adapter recyclerView_Adapter;
    RecyclerView.LayoutManager recyclerView_LayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //load data
        notesArrayList = loadNotesList();
        //set Recyclerview
        recyclerView_View = findViewById(R.id.recycle_view);
        recyclerView_View.setHasFixedSize(true);
        recyclerView_LayoutManager = new LinearLayoutManager(this);
        ((LinearLayoutManager) recyclerView_LayoutManager).setReverseLayout(true);
        recyclerView_Adapter = new Radapter(SimpleNote.this, notesArrayList);
        recyclerView_View.setLayoutManager(recyclerView_LayoutManager);
        recyclerView_View.setAdapter(recyclerView_Adapter);

        //swipe delete
        ItemTouchHelper.SimpleCallback simpleItemTouchCallback =
                new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.RIGHT) {
                    @Override
                    public boolean onMove(RecyclerView recyclerView,
                                          RecyclerView.ViewHolder viewHolder,
                                          RecyclerView.ViewHolder target) {
                        return false;
                    }

                    @Override
                    public void onSwiped(RecyclerView.ViewHolder viewHolder, int swipeDir) {
                        //Remove swiped item from list and notify the RecyclerView
                        int position = viewHolder.getAdapterPosition();
                        Notes delete_file = notesArrayList.get(position);
                        String file_name = delete_file.filename;
                        File dir = getFilesDir();
                        File file = new File(dir, file_name);
                        file.delete();
                        notesArrayList.remove(position);//position removed from the list
                        loadNotesList();
                        removeData(loadNotesList());
                        recyclerView_Adapter.notifyItemRemoved(position);
                    }

                    Paint paint;

                    public Paint getPaintObject() {

                        if (paint == null)
                            paint = new Paint();
                        return paint;
                    }

                    public static final float ALPHA_FULL = 1.0f;

                    public void onChildDraw(Canvas c, RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, float dX, float dY, int actionState, boolean isCurrentlyActive) {
                        if (actionState == ItemTouchHelper.ACTION_STATE_SWIPE) {

                            View itemView = viewHolder.itemView;
                            Paint p = getPaintObject();
                            if (dX > 0) {
                                p.setARGB(255, 255, 0, 0);
                                c.drawRect((float) itemView.getLeft(), (float) itemView.getTop(), dX,
                                        (float) itemView.getBottom(), p);
                            }
                            final float alpha = ALPHA_FULL - Math.abs(dX) / (float) viewHolder.itemView.getWidth();
                            viewHolder.itemView.setAlpha(alpha);
                            viewHolder.itemView.setTranslationX(dX);

                        } else {
                            super.onChildDraw(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive);
                        }
                    }
                };
        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(simpleItemTouchCallback);
        itemTouchHelper.attachToRecyclerView(recyclerView_View);
        mFloatingActionButton = (FloatingActionButton) findViewById(R.id.fab);
        mFloatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addItem();
            }
        });
    }


    public ArrayList<Notes> loadNotesList() {
        SharedPreferences sp = getSharedPreferences("FILE", MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        Gson gson = new Gson();
        String jsonNotes = sp.getString(KEY, null);
        Type type = new TypeToken<ArrayList<Notes>>() {
        }.getType();
        if (jsonNotes != null) {
            notesArrayList = gson.fromJson(jsonNotes, type);
            Log.d(TAG, "LoadArraylist: " + jsonNotes);
        } else {
            notesArrayList = new ArrayList<Notes>();
            Log.d(TAG, "LoadArraylist: is null " + jsonNotes);
        }
        return notesArrayList;
    }

    public void addItem() {
        Intent create_intent = new Intent(SimpleNote.this, InputSection.class);
        startActivityForResult(create_intent, LAUNCH_SECOND_ACTIVITY);
    }

    public void saveData(String filename, String title, Long time) {
        SharedPreferences sp = getSharedPreferences("FILE", MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        Gson gson = new Gson();
        notesList = notesArrayList;
        notesList.add(new Notes(filename, title, time));
        String jsonNotes = gson.toJson(notesList);
        Log.d(TAG, "saveArraylist: " + jsonNotes);
        editor.remove("Notes");
        editor.putString("Notes", jsonNotes);
        editor.commit();
        loadNotesList();
        recyclerView_Adapter.notifyDataSetChanged();
    }

    public void removeData(ArrayList<Notes> notesArrayList) {
        SharedPreferences sp = getSharedPreferences("FILE", MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        Gson gson = new Gson();
        notesList = notesArrayList;
        String jsonNotes = gson.toJson(notesList);
        Log.d(TAG, "saveArraylist: " + jsonNotes);
        editor.remove("Notes");
        editor.putString("Notes", jsonNotes);
        editor.commit();
        loadNotesList();
        recyclerView_Adapter.notifyDataSetChanged();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Log.d(TAG, "onActivityResult: " + "requestcode " + requestCode + " " +
                "resultcode " + resultCode);
        super.onActivityResult(requestCode, resultCode, data);
        recyclerView_Adapter.notifyDataSetChanged();
        if (requestCode == LAUNCH_SECOND_ACTIVITY) {
            if (resultCode == Activity.RESULT_OK) {
                String filename = data.getStringExtra("filename");
                String title = data.getStringExtra("title");
                Long time = data.getLongExtra("time", 0);
                saveData(filename, title, time);
            }
            if (resultCode == Activity.RESULT_CANCELED) {
                Log.d(TAG, "onActivityResult: " + "not getbacked");
            }
        }
    }
}


